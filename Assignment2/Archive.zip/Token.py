class Token:
    def __init__(self, lex, tC):
        self.lexeme = lex
        self.tCode = tC
